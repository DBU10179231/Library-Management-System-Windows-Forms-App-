﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Linq; // Added for .FirstOrDefault()
using System.Windows.Forms;

namespace LibraryMgtSystem
{
    public partial class Issue_Book : Form
    {
        // Connection string for the Issue_Book form
        // IMPORTANT: In a production application, store connection strings securely
        // (e.g., in App.config or Web.config) rather than hardcoding them.
        private string connectionString = "Server=localhost;Database=LibrarySystem;Uid=admin;Pwd=admin123;";

        public Issue_Book()
        {
            InitializeComponent();
            InitializeCustomComponents(); // Custom initialization for labels and dates
            this.Load += new System.EventHandler(this.Issue_Book_Load);
        }

        // Custom initialization for UI elements
        private void InitializeCustomComponents()
        {
            // Find the error message label (label7) and initialize its state
            Label lblErrorMessage = this.Controls.Find("label7", true).FirstOrDefault() as Label;
            if (lblErrorMessage != null)
            {
                lblErrorMessage.Text = ""; // Clear any default text
                lblErrorMessage.ForeColor = System.Drawing.Color.Red; // Set color for errors
            }

            // Set default dates for Issue Date (dateTimePicker1) and Due Date (dateTimePicker2)
            DateTimePicker dtpIssueDate = this.Controls.Find("dateTimePicker1", true).FirstOrDefault() as DateTimePicker;
            DateTimePicker dtpDueDate = this.Controls.Find("dateTimePicker2", true).FirstOrDefault() as DateTimePicker;

            if (dtpIssueDate != null) dtpIssueDate.Value = DateTime.Now.Date;
            if (dtpDueDate != null) dtpDueDate.Value = DateTime.Now.Date.AddDays(14); // Default due date 2 weeks from issue
        }

        // Event handler for the Issue_Book form Load event
        private void Issue_Book_Load(object sender, EventArgs e)
        {
            LoadBorrowersIntoComboBox(); // Populate borrower dropdown
            LoadBooksIntoComboBox();     // Populate book dropdown
        }

        // Method to load borrowers into comboBox1
        private void LoadBorrowersIntoComboBox()
        {
            ComboBox cboBorrower = this.Controls.Find("comboBox1", true).FirstOrDefault() as ComboBox; // Assuming comboBox1
            if (cboBorrower == null)
            {
                MessageBox.Show("Borrower ComboBox (comboBox1) not found. Please ensure it exists and is named correctly.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT BorrowerID, Name FROM Borrowers ORDER BY Name";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                        {
                            DataTable borrowers = new DataTable();
                            adapter.Fill(borrowers); // Fill DataTable with borrowers

                            cboBorrower.DisplayMember = "Name";     // Display borrower's name
                            cboBorrower.ValueMember = "BorrowerID"; // Use BorrowerID as the value
                            cboBorrower.DataSource = borrowers;     // Bind data to ComboBox
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Database error loading borrowers: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error occurred loading borrowers: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Method to load available books into comboBox2
        private void LoadBooksIntoComboBox()
        {
            ComboBox cboBook = this.Controls.Find("comboBox2", true).FirstOrDefault() as ComboBox; // Assuming comboBox2
            if (cboBook == null)
            {
                MessageBox.Show("Book ComboBox (comboBox2) not found. Please ensure it exists and is named correctly.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    // Select only books with available copies
                    string query = "SELECT BookID, Title, AvailableCopies FROM Books WHERE AvailableCopies > 0 ORDER BY Title";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                        {
                            DataTable books = new DataTable();
                            adapter.Fill(books); // Fill DataTable with books

                            cboBook.DisplayMember = "Title"; // Display book title
                            cboBook.ValueMember = "BookID";  // Use BookID as the value
                            cboBook.DataSource = books;      // Bind data to ComboBox
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Database error loading books: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error occurred loading books: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Event handler for the Issue Button (button1) click
        private void button1_Click(object sender, EventArgs e) // Issue Button
        {
            Label lblErrorMessage = this.Controls.Find("label7", true).FirstOrDefault() as Label;
            // Clear previous error message
            if (lblErrorMessage != null) lblErrorMessage.Text = "";

            // Get references to UI controls
            ComboBox cboBorrower = this.Controls.Find("comboBox1", true).FirstOrDefault() as ComboBox;
            ComboBox cboBook = this.Controls.Find("comboBox2", true).FirstOrDefault() as ComboBox;
            DateTimePicker dtpIssueDate = this.Controls.Find("dateTimePicker1", true).FirstOrDefault() as DateTimePicker;
            DateTimePicker dtpDueDate = this.Controls.Find("dateTimePicker2", true).FirstOrDefault() as DateTimePicker;

            // Check if UI controls are found
            if (cboBorrower == null || cboBook == null || dtpIssueDate == null || dtpDueDate == null || lblErrorMessage == null)
            {
                MessageBox.Show("One or more UI controls (comboBox1, comboBox2, dateTimePicker1, dateTimePicker2, label7) were not found. Please ensure they exist and are named correctly in the designer.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Input Validation: Check if borrower and book are selected
            if (cboBorrower.SelectedValue == null)
            {
                lblErrorMessage.Text = "Please select a borrower.";
                return;
            }
            if (cboBook.SelectedValue == null)
            {
                lblErrorMessage.Text = "Please select a book.";
                return;
            }

            int borrowerId = Convert.ToInt32(cboBorrower.SelectedValue);
            int bookId = Convert.ToInt32(cboBook.SelectedValue);
            DateTime issueDate = dtpIssueDate.Value.Date;
            DateTime dueDate = dtpDueDate.Value.Date;

            // Input Validation: Due Date cannot be before Issue Date
            if (dueDate < issueDate)
            {
                lblErrorMessage.Text = "Due Date cannot be before Issue Date.";
                return;
            }

            // Re-check available copies to prevent race conditions in a multi-user environment
            int currentAvailableCopies = 0;
            using (MySqlConnection connectionCheck = new MySqlConnection(connectionString))
            {
                try
                {
                    connectionCheck.Open();
                    string checkCopiesQuery = "SELECT AvailableCopies FROM Books WHERE BookID = @bookId";
                    using (MySqlCommand checkCmd = new MySqlCommand(checkCopiesQuery, connectionCheck))
                    {
                        checkCmd.Parameters.AddWithValue("@bookId", bookId);
                        object result = checkCmd.ExecuteScalar();
                        currentAvailableCopies = (result != null && result != DBNull.Value) ? Convert.ToInt32(result) : 0;
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Database error checking available copies: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error occurred checking available copies: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            if (currentAvailableCopies <= 0)
            {
                lblErrorMessage.Text = "No available copies for this book. Please select another book.";
                return;
            }

            // Use a transaction for atomicity: Decrement copies AND insert issued record
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlTransaction transaction = null;

            try
            {
                connection.Open();
                transaction = connection.BeginTransaction(); // Start transaction

                // 1. Decrement AvailableCopies in Books table
                string updateBookQuery = "UPDATE Books SET AvailableCopies = AvailableCopies - 1 WHERE BookID = @bookId AND AvailableCopies > 0";
                MySqlCommand updateBookCmd = new MySqlCommand(updateBookQuery, connection, transaction);
                updateBookCmd.Parameters.AddWithValue("@bookId", bookId);
                int booksAffected = updateBookCmd.ExecuteNonQuery();

                if (booksAffected == 0)
                {
                    // This means another process might have taken the last copy right after our check
                    throw new InvalidOperationException("Failed to decrement book copies. The book might have become unavailable.");
                }

                // 2. Insert record into IssuedBooks table
                string insertIssuedBookQuery = "INSERT INTO IssuedBooks (BookID, BorrowerID, IssueDate, DueDate) VALUES (@bookId, @borrowerId, @issueDate, @dueDate)";
                MySqlCommand insertIssuedBookCmd = new MySqlCommand(insertIssuedBookQuery, connection, transaction);
                insertIssuedBookCmd.Parameters.AddWithValue("@bookId", bookId);
                insertIssuedBookCmd.Parameters.AddWithValue("@borrowerId", borrowerId);
                insertIssuedBookCmd.Parameters.AddWithValue("@issueDate", issueDate);
                insertIssuedBookCmd.Parameters.AddWithValue("@dueDate", dueDate);
                insertIssuedBookCmd.ExecuteNonQuery();

                transaction.Commit(); // Commit the transaction if all operations succeed
                MessageBox.Show("Book issued successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK; // Indicate success to calling form
                this.Close(); // Close the form
            }
            catch (InvalidOperationException ex)
            {
                transaction?.Rollback(); // Rollback if our quantity decrement failed
                MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                lblErrorMessage.Text = ex.Message;
            }
            catch (MySqlException ex)
            {
                transaction?.Rollback(); // Rollback transaction on MySQL error
                MessageBox.Show("Database error during issue: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblErrorMessage.Text = "Database error during issue.";
            }
            catch (Exception ex)
            {
                transaction?.Rollback(); // Rollback transaction on any other error
                MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblErrorMessage.Text = "An unexpected error occurred.";
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close(); // Ensure connection is closed
                }
            }
        }

        // Event handler for the Cancel Button (button2) click
        private void button2_Click(object sender, EventArgs e) // Cancel Button
        {
            this.DialogResult = DialogResult.Cancel; // Set dialog result to Cancel
            this.Close(); // Close the form
        }

        // Empty Event handlers for controls (can be removed if no specific logic needed)
        private void label1_Click(object sender, EventArgs e) { } // Borrower Label
        private void label2_Click(object sender, EventArgs e) { } // Book Label
        private void label4_Click(object sender, EventArgs e) { } // Issue Date Label
        private void label5_Click(object sender, EventArgs e) { } // Due Date Label
        private void label6_Click(object sender, EventArgs e) { } // Placeholder label (if any)
        private void textBox1_TextChanged(object sender, EventArgs e) { } // Unused/Placeholder Textbox (likely related to old design)
        private void textBox2_TextChanged(object sender, EventArgs e) { } // Unused/Placeholder Textbox
        private void textBox3_TextChanged(object sender, EventArgs e) { } // Unused/Placeholder Textbox
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e) { } // Issue Date
        private void dateTimePicker2_ValueChanged(object sender, EventArgs e) { } // Due Date
    }
}
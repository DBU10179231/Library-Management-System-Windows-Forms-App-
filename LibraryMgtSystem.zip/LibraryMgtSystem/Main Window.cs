﻿// Main_Window.cs
// This file defines the main application window and its logic.

using MySql.Data.MySqlClient; // Using MySQL client library
using System;
using System.Data; // For DataTable
using System.Linq; // For .FirstOrDefault()
using System.Windows.Forms; // For Windows Forms UI elements

namespace LibraryMgtSystem
{
    public partial class Main_Window : Form
    {
        // MySQL Connection String.
        // IMPORTANT: Adjust Server, Database, Uid, and Pwd to match your MySQL setup.
        private string connectionString = "Server=localhost;Database=LibrarySystem;Uid=admin;Pwd=admin123;";

        // Private field to store the username of the currently logged-in user.
        private string _loggedInUsername;

        // --- Constructors ---

        // Parameterized constructor: Called from Loginform after successful login.
        public Main_Window(string username)
        {
            InitializeComponent();
            _loggedInUsername = username; // Store the passed username
            this.Text = $"Library Management System - Logged in as: {_loggedInUsername}"; // Update form title

            this.Load += Main_Window_Load; // Hook up the form load event

            // Attempt to find the TabControl and hook up its Selected event.
            TabControl tabControl = this.Controls.Find("tabControl1", true).FirstOrDefault() as TabControl;
            if (tabControl != null)
            {
                tabControl.Selected += tabControl1_Selected;
            }
            else
            {
                // Optionally, warn if tabControl1 is not found, as it's crucial for tab switching logic.
                MessageBox.Show("TabControl 'tabControl1' not found. Tab-specific data loading may not work.", "UI Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // Find and display welcome message (assuming a label named labelWelcome exists)
            Label labelWelcome = this.Controls.Find("labelWelcome", true).FirstOrDefault() as Label;
            if (labelWelcome != null)
            {
                labelWelcome.Text = $"Welcome, {_loggedInUsername}!";
                labelWelcome.AutoSize = true;
                labelWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                labelWelcome.Location = new System.Drawing.Point(20, 20); // Example position
            }
        }

        // Parameterless constructor (if your designer or other parts of your code call it without arguments)
        // Keep this if you have components that might initialize Main_Window without a username.
        // If only the Loginform creates Main_Window, you might not strictly need this,
        // but it doesn't hurt to have for flexibility or if Visual Studio adds it.
        public Main_Window() : this("Guest") // Calls the parameterized constructor with a default "Guest" username
        {
            // Any additional initialization specific to the parameterless constructor can go here.
            // In most cases, it just calls the main constructor.
        }

        // --- Event Handlers ---

        private void Main_Window_Load(object sender, EventArgs e)
        {
            // Initial data load for the default tab when the form loads.
            // Assuming your first tab is 'Books Management' or similar.
            LoadBooksData(); // Call a method to load initial data.
        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            // This event fires when a new tab is selected.
            // Check the name of the newly selected tab page to load specific data.
            if (e.TabPage.Name == "tabPage2") // Assuming 'tabPage2' is for Issued Books Overview
            {
                LoadIssuedBooksOverviewData();
            }
            else if (e.TabPage.Name == "booksManagementTabPage" || e.TabPage.Text == "Books Management")
            {
                LoadBooksData(); // Reload data for Books Management tab
            }
            else if (e.TabPage.Name == "borrowersManagementTabPage" || e.TabPage.Text == "Borrowers Management")
            {
                LoadBorrowersData(); // Reload data for Borrowers Management tab
            }
            // Add more else if blocks for other tabs as needed.
        }

        // --- Data Loading Methods ---

        private void LoadIssuedBooksOverviewData()
        {
            // Find the TabControl by its name.
            TabControl mainTabControl = this.Controls.Find("tabControl1", true).FirstOrDefault() as TabControl;
            if (mainTabControl == null)
            {
                MessageBox.Show("Main TabControl (tabControl1) not found. Please ensure it exists and is named correctly.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Find the specific TabPage within the TabControl.
            // Ensure your tab page for issued books is named "tabPage2" in the designer.
            TabPage tabPage2 = mainTabControl.Controls.Find("tabPage2", true).FirstOrDefault() as TabPage;
            if (tabPage2 == null)
            {
                MessageBox.Show("Issued Books Overview TabPage (tabPage2) not found within tabControl1. Please ensure it exists and is named correctly.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Find the DataGridView within that TabPage.
            // Ensure your DataGridView for issued books is named "dataGridView3" in the designer.
            DataGridView dgvIssuedBooksOverview = tabPage2.Controls.Find("dataGridView3", true).FirstOrDefault() as DataGridView;
            if (dgvIssuedBooksOverview == null)
            {
                MessageBox.Show("Issued Books Overview DataGridView (dataGridView3) not found on tabPage2. Please ensure it exists and is named correctly.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Configure DataGridView properties (these are good defaults)
            dgvIssuedBooksOverview.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvIssuedBooksOverview.ReadOnly = true;
            dgvIssuedBooksOverview.AllowUserToAddRows = false;
            dgvIssuedBooksOverview.AllowUserToDeleteRows = false;
            dgvIssuedBooksOverview.MultiSelect = false;
            dgvIssuedBooksOverview.AutoGenerateColumns = true; // Set to false if you manually define columns
            dgvIssuedBooksOverview.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            using (MySqlConnection connection = new MySqlConnection(connectionString)) // Changed to MySqlConnection
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT
                            ib.IssueID,
                            b.Title AS BookTitle,
                            bo.Name AS BorrowerName,
                            ib.IssueDate,
                            ib.DueDate,
                            ib.ReturnDate
                        FROM IssuedBooks ib
                        JOIN Books b ON ib.BookID = b.BookID
                        JOIN Borrowers bo ON ib.BorrowerID = bo.BorrowerID
                        ORDER BY ib.IssueDate DESC";

                    using (MySqlCommand command = new MySqlCommand(query, connection)) // Changed to MySqlCommand
                    {
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(command)) // Changed to MySqlDataAdapter
                        {
                            DataTable issuedBooks = new DataTable();
                            adapter.Fill(issuedBooks);
                            dgvIssuedBooksOverview.DataSource = issuedBooks;

                            // Hide internal IDs if desired
                            if (dgvIssuedBooksOverview.Columns.Contains("IssueID"))
                            {
                                dgvIssuedBooksOverview.Columns["IssueID"].Visible = false;
                            }
                            // You might also want to hide BookID and BorrowerID if they are implicitly selected
                            // if (dgvIssuedBooksOverview.Columns.Contains("BookID")) dgvIssuedBooksOverview.Columns["BookID"].Visible = false;
                            // if (dgvIssuedBooksOverview.Columns.Contains("BorrowerID")) dgvIssuedBooksOverview.Columns["BorrowerID"].Visible = false;
                        }
                    }
                }
                catch (MySqlException ex) // Changed to MySqlException
                {
                    MessageBox.Show("Database error loading issued books overview: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error occurred loading issued books overview: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Placeholder methods for other data loading (ensure they exist in your UI)
        private void LoadBooksData()
        {
            // Example: Load data into dataGridView1 (if you have one for books)
            // DataGridView dgvBooks = this.Controls.Find("dataGridView1", true).FirstOrDefault() as DataGridView;
            // if (dgvBooks != null) { ... your MySQL query for books ... dgvBooks.DataSource = dataTable; }
            Console.WriteLine("Loading Books Data..."); // For debugging
        }

        private void LoadBorrowersData()
        {
            // Example: Load data into dataGridView2 (if you have one for borrowers)
            // DataGridView dgvBorrowers = this.Controls.Find("dataGridView2", true).FirstOrDefault() as DataGridView;
            // if (dgvBorrowers != null) { ... your MySQL query for borrowers ... dgvBorrowers.DataSource = dataTable; }
            Console.WriteLine("Loading Borrowers Data..."); // For debugging
        }

        // --- Placeholder Event Handlers to Resolve CS1061 Errors ---
        // These methods are required because your Main_Window.Designer.cs indicates they exist.
        // If you don't intend to use a specific button or DataGridView event,
        // you can go to the designer, select the control, go to its Properties (lightning bolt icon for Events),
        // and clear the event handler name from the list.

        private void button3_Click(object sender, EventArgs e)
        {
            // Example: Add your logic for button3 here.
            MessageBox.Show("Button 3 Clicked!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Example: Add your logic for button2 here.
            MessageBox.Show("Button 2 Clicked!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Example: Add your logic for button1 here.
            MessageBox.Show("Button 1 Clicked!");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Example: Add your logic for DataGridView1 cell click here.
            Console.WriteLine("DataGridView1 Cell Clicked!");
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Example: Add your logic for DataGridView2 cell click here.
            Console.WriteLine("DataGridView2 Cell Clicked!");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Example: Add your logic for button5 here.
            MessageBox.Show("Button 5 Clicked!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Example: Add your logic for button4 here.
            MessageBox.Show("Button 4 Clicked!");
        }

        // --- Other Methods from your provided code ---
        private void btnAddBook_Click(object sender, EventArgs e)
        {
            // This suggests you have a separate form for Books_Management.
            // Make sure you have that form defined and it's able to refresh data.
            // Books_Management addForm = new Books_Management();
            // if (addForm.ShowDialog() == DialogResult.OK)
            // {
            //     LoadBooksData(); // Refresh the books list after adding
            // }
            MessageBox.Show("Add Book button clicked!");
        }

        private void btnEditBook_Click(object sender, EventArgs e)
        {
            // Logic to get selected book data from DataGridView for editing.
            // MessageBox.Show("Edit Book button clicked!");
            // Books_Management editForm = new Books_Management(bookId, title, author, year, availableCopies);
            // if (editForm.ShowDialog() == DialogResult.OK) { LoadBooksData(); }
            MessageBox.Show("Edit Book button clicked!");
        }

        // You might have other button click handlers (e.g., btnDeleteBook_Click, btnIssueBook_Click, etc.)
        // Add them here if they are in your Main_Window.Designer.cs
        // private void btnDeleteBook_Click(object sender, EventArgs e) { /* ... */ }
        // private void btnIssueBook_Click(object sender, EventArgs e) { /* ... */ }
    }
}

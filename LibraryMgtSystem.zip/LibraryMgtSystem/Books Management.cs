﻿using MySql.Data.MySqlClient;
using System;
using System.Linq; // Added for .FirstOrDefault()
using System.Windows.Forms;

namespace LibraryMgtSystem
{
    public partial class Books_Management : Form
    {
        // Connection string for the Books_Management form
        // IMPORTANT: In a production application, store connection strings securely.
        private string connectionString = "Server=localhost;Database=LibrarySystem;Uid=admin;Pwd=admin123;";

        public int BookID { get; set; } // Property to hold the BookID if editing
        public bool IsEditMode { get; set; } = false; // Flag to indicate add or edit mode

        // Default constructor for adding a new book
        public Books_Management()
        {
            InitializeComponent();
            InitializeCustomComponents(); // Custom initialization for labels and error message

            // Hide BookID label (label1) and textbox (textBox1) by default for 'Add' mode
            Label lblBookID = this.Controls.Find("label1", true).FirstOrDefault() as Label;
            TextBox txtBookID = this.Controls.Find("textBox1", true).FirstOrDefault() as TextBox;

            if (lblBookID != null) lblBookID.Visible = false;
            if (txtBookID != null) txtBookID.Visible = false;
        }

        // Constructor for editing an existing book
        // Pre-populates fields with existing book data
        public Books_Management(int bookId, string title, string author, int year, int availableCopies) : this() // Calls the default constructor first
        {
            IsEditMode = true; // Set to edit mode
            BookID = bookId; // Store the BookID

            // Get references to UI controls
            TextBox txtBookID = this.Controls.Find("textBox1", true).FirstOrDefault() as TextBox;
            TextBox txtTitle = this.Controls.Find("textBox2", true).FirstOrDefault() as TextBox;
            TextBox txtAuthor = this.Controls.Find("textBox3", true).FirstOrDefault() as TextBox;
            TextBox txtYear = this.Controls.Find("textBox4", true).FirstOrDefault() as TextBox;
            TextBox txtAvailableCopies = this.Controls.Find("textBox5", true).FirstOrDefault() as TextBox; // Assuming textBox5 for AvailableCopies
            Label lblBookID = this.Controls.Find("label1", true).FirstOrDefault() as Label;

            // Populate textboxes with existing data
            if (txtBookID != null)
            {
                txtBookID.Text = bookId.ToString();
                txtBookID.Visible = true; // Show BookID in edit mode
                txtBookID.ReadOnly = true; // Make BookID read-only to prevent accidental changes
            }
            if (txtTitle != null) txtTitle.Text = title;
            if (txtAuthor != null) txtAuthor.Text = author;
            if (txtYear != null) txtYear.Text = year.ToString();
            if (txtAvailableCopies != null) txtAvailableCopies.Text = availableCopies.ToString();

            if (lblBookID != null) lblBookID.Visible = true; // Show BookID label
        }

        // Custom initialization for UI elements (called by both constructors)
        private void InitializeCustomComponents()
        {
            // Find the error message label (label6) and initialize its state
            Label lblErrorMessage = this.Controls.Find("label6", true).FirstOrDefault() as Label;
            if (lblErrorMessage != null)
            {
                lblErrorMessage.Text = ""; // Clear any default text
                lblErrorMessage.ForeColor = System.Drawing.Color.Red; // Set color for errors
            }
        }

        // Event handler for the Save Button (button1) click
        private void button1_Click(object sender, EventArgs e) // Save Button
        {
            Label lblErrorMessage = this.Controls.Find("label6", true).FirstOrDefault() as Label;
            // Clear previous error message
            if (lblErrorMessage != null) lblErrorMessage.Text = "";

            // Get references to UI controls
            TextBox txtTitle = this.Controls.Find("textBox2", true).FirstOrDefault() as TextBox;
            TextBox txtAuthor = this.Controls.Find("textBox3", true).FirstOrDefault() as TextBox;
            TextBox txtYear = this.Controls.Find("textBox4", true).FirstOrDefault() as TextBox;
            TextBox txtAvailableCopies = this.Controls.Find("textBox5", true).FirstOrDefault() as TextBox; // Assuming textBox5 for AvailableCopies

            // Check if UI controls are found
            if (txtTitle == null || txtAuthor == null || txtYear == null || txtAvailableCopies == null || lblErrorMessage == null)
            {
                MessageBox.Show("One or more UI controls (textBox2, textBox3, textBox4, textBox5, label6) were not found. Please ensure they exist and are named correctly in the designer.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Input Validation: Check for empty fields
            if (string.IsNullOrWhiteSpace(txtTitle.Text) || string.IsNullOrWhiteSpace(txtAuthor.Text) ||
                string.IsNullOrWhiteSpace(txtYear.Text) || string.IsNullOrWhiteSpace(txtAvailableCopies.Text))
            {
                lblErrorMessage.Text = "All fields are required.";
                return;
            }

            // Input Validation: Validate Year as integer and within reasonable range
            if (!int.TryParse(txtYear.Text, out int year) || year < 1000 || year > DateTime.Now.Year + 10)
            {
                lblErrorMessage.Text = "Please enter a valid year (e.g., 1990, not in the distant future).";
                return;
            }

            // Input Validation: Validate Available Copies as non-negative integer
            if (!int.TryParse(txtAvailableCopies.Text, out int availableCopies) || availableCopies < 0)
            {
                lblErrorMessage.Text = "Available Copies must be a non-negative number.";
                return;
            }

            // Database connection and CRUD operation
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open(); // Open database connection
                    string query;
                    MySqlCommand command;

                    if (IsEditMode)
                    {
                        // Retrieve BookID from the textbox (it should be read-only in edit mode)
                        TextBox txtBookID = this.Controls.Find("textBox1", true).FirstOrDefault() as TextBox;
                        if (txtBookID == null || !int.TryParse(txtBookID.Text, out int parsedBookID))
                        {
                            MessageBox.Show("Book ID TextBox (textBox1) not found or contains an invalid ID in edit mode. Cannot update.", "Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        BookID = parsedBookID; // Ensure the class property is updated from the UI

                        // Update existing book
                        query = "UPDATE Books SET Title = @title, Author = @author, Year = @year, AvailableCopies = @availableCopies WHERE BookID = @bookId";
                        command = new MySqlCommand(query, connection);
                        command.Parameters.AddWithValue("@title", txtTitle.Text.Trim());
                        command.Parameters.AddWithValue("@author", txtAuthor.Text.Trim());
                        command.Parameters.AddWithValue("@year", year);
                        command.Parameters.AddWithValue("@availableCopies", availableCopies);
                        command.Parameters.AddWithValue("@bookId", BookID);
                    }
                    else
                    {
                        // Insert new book
                        query = "INSERT INTO Books (Title, Author, Year, AvailableCopies) VALUES (@title, @author, @year, @availableCopies)";
                        command = new MySqlCommand(query, connection);
                        command.Parameters.AddWithValue("@title", txtTitle.Text.Trim());
                        command.Parameters.AddWithValue("@author", txtAuthor.Text.Trim());
                        command.Parameters.AddWithValue("@year", year);
                        command.Parameters.AddWithValue("@availableCopies", availableCopies);
                    }

                    int rowsAffected = command.ExecuteNonQuery(); // Execute the command

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show(IsEditMode ? "Book updated successfully!" : "Book added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.DialogResult = DialogResult.OK; // Set dialog result to OK to indicate success to calling form
                        this.Close(); // Close the form
                    }
                    else
                    {
                        lblErrorMessage.Text = IsEditMode ? "Failed to update book. No changes made or book not found." : "Failed to add book. No rows affected.";
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Database error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    lblErrorMessage.Text = "Database error: " + ex.Message;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    lblErrorMessage.Text = "An unexpected error occurred.";
                }
            }
        }

        // Event handler for the Cancel Button (button2) click
        private void button2_Click(object sender, EventArgs e) // Cancel Button
        {
            this.DialogResult = DialogResult.Cancel; // Set dialog result to Cancel
            this.Close(); // Close the form
        }

        // Empty Event handlers for controls (can be removed if no specific logic needed)
        private void label1_Click(object sender, EventArgs e) { } // BookID Label
        private void label2_Click(object sender, EventArgs e) { } // Title Label
        private void label3_Click(object sender, EventArgs e) { } // Author Label
        private void label4_Click(object sender, EventArgs e) { } // Year Label
        private void label5_Click(object sender, EventArgs e) { } // Available Copies Label
        private void label6_Click(object sender, EventArgs e) { } // Error message label
        private void textBox1_TextChanged(object sender, EventArgs e) { } // BookID Textbox
        private void textBox2_TextChanged(object sender, EventArgs e) { } // Title Textbox
        private void textBox3_TextChanged(object sender, EventArgs e) { } // Author Textbox
        private void textBox4_TextChanged(object sender, EventArgs e) { } // Year Textbox
        private void textBox5_TextChanged(object sender, EventArgs e) { } // AvailableCopies Textbox
    }
}
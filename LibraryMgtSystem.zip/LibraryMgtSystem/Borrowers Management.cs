﻿using MySql.Data.MySqlClient;
using System;
using System.Linq; // Added for .FirstOrDefault()
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace LibraryMgtSystem
{
    public partial class Borrowers_Management : Form
    {
        // Connection string for the Borrowers_Management form
        private string connectionString = "Server=localhost;Database=LibrarySystem;Uid=admin;Pwd=admin123;"; // Set to admin/admin123

        public int BorrowerID { get; set; }
        public bool IsEditMode { get; set; } = false;

        public Borrowers_Management()
        {
            InitializeComponent();
            // Find the error message label (label5) and initialize its state
            Label lblErrorMessage = this.Controls.Find("label5", true).FirstOrDefault() as Label;
            if (lblErrorMessage != null)
            {
                lblErrorMessage.Text = "";
                lblErrorMessage.ForeColor = System.Drawing.Color.Red;
            }

            // Hide BorrowerID label (label1) and textbox (textBox1) by default for 'Add' mode
            Label lblBorrowerID = this.Controls.Find("label1", true).FirstOrDefault() as Label;
            TextBox txtBorrowerID = this.Controls.Find("textBox1", true).FirstOrDefault() as TextBox;

            if (lblBorrowerID != null) lblBorrowerID.Visible = false;
            if (txtBorrowerID != null) txtBorrowerID.Visible = false;

            // Ensure button1's Click (Save) and button2's Click (Cancel) events are hooked in the designer.
            // Also ensure the form's Load event is hooked to Borrowers_Management_Load.
        }

        // Constructor for editing an existing borrower
        // Pre-populates fields with existing borrower data
        public Borrowers_Management(int borrowerId, string name, string email, string phone) : this()
        {
            IsEditMode = true; // Set to edit mode
            BorrowerID = borrowerId; // Store the BorrowerID

            // Get references to UI controls
            TextBox txtBorrowerID = this.Controls.Find("textBox1", true).FirstOrDefault() as TextBox;
            TextBox txtName = this.Controls.Find("textBox2", true).FirstOrDefault() as TextBox;
            TextBox txtEmail = this.Controls.Find("textBox3", true).FirstOrDefault() as TextBox;
            TextBox txtPhone = this.Controls.Find("textBox4", true).FirstOrDefault() as TextBox;
            Label lblBorrowerID = this.Controls.Find("label1", true).FirstOrDefault() as Label;

            // Populate textboxes with existing data
            if (txtBorrowerID != null)
            {
                txtBorrowerID.Text = borrowerId.ToString();
                txtBorrowerID.Visible = true; // Show BorrowerID in edit mode
                txtBorrowerID.ReadOnly = true; // Make BorrowerID read-only
            }
            if (txtName != null) txtName.Text = name;
            if (txtEmail != null) txtEmail.Text = email;
            if (txtPhone != null) txtPhone.Text = phone;

            if (lblBorrowerID != null) lblBorrowerID.Visible = true; // Show BorrowerID label
        }

        // Event handlers for various labels (no specific logic needed)
        private void label1_Click(object sender, EventArgs e) { } // BorrowerID Label
        private void label2_Click(object sender, EventArgs e) { } // Name Label
        private void label3_Click(object sender, EventArgs e) { } // Email Label
        private void label4_Click(object sender, EventArgs e) { } // Phone Label
        private void label5_Click(object sender, EventArgs e) { } // Error Message Label


        // Event handlers for various TextBoxes (no specific logic needed)
        private void textBox1_TextChanged(object sender, EventArgs e) { } // BorrowerID
        private void textBox2_TextChanged(object sender, EventArgs e) { } // Name
        private void textBox3_TextChanged(object sender, EventArgs e) { } // Email
        private void textBox4_TextChanged(object sender, EventArgs e) { } // Phone

        // Event handler for the Save Button (button1) click
        private void button1_Click(object sender, EventArgs e) // Save Button
        {
            // Get references to UI controls
            TextBox txtName = this.Controls.Find("textBox2", true).FirstOrDefault() as TextBox;
            TextBox txtEmail = this.Controls.Find("textBox3", true).FirstOrDefault() as TextBox;
            TextBox txtPhone = this.Controls.Find("textBox4", true).FirstOrDefault() as TextBox;
            Label lblErrorMessage = this.Controls.Find("label5", true).FirstOrDefault() as Label; // Assuming label5 for errors

            // Check if UI controls are found
            if (txtName == null || txtEmail == null || txtPhone == null || lblErrorMessage == null)
            {
                MessageBox.Show("UI controls (textBox2, textBox3, textBox4, label5) not found. Please ensure they exist and are named correctly in the designer.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Input Validation: Check for empty fields
            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                lblErrorMessage.Text = "Name and Email are required.";
                return;
            }

            // Input Validation: Validate email format using Regex
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            if (!Regex.IsMatch(txtEmail.Text.Trim(), emailPattern))
            {
                lblErrorMessage.Text = "Please enter a valid email address.";
                return;
            }

            // Database connection and CRUD operation
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open(); // Open database connection
                    string query;
                    MySqlCommand command;

                    if (IsEditMode)
                    {
                        // Update existing borrower
                        TextBox txtBorrowerID = this.Controls.Find("textBox1", true).FirstOrDefault() as TextBox;
                        if (txtBorrowerID == null || !int.TryParse(txtBorrowerID.Text, out int parsedBorrowerID))
                        {
                            MessageBox.Show("Borrower ID TextBox (textBox1) not found or invalid ID in edit mode.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        BorrowerID = parsedBorrowerID;

                        query = "UPDATE Borrowers SET Name = @name, Email = @email, Phone = @phone WHERE BorrowerID = @borrowerId";
                        command = new MySqlCommand(query, connection);
                        command.Parameters.AddWithValue("@name", txtName.Text.Trim());
                        command.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                        command.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                        command.Parameters.AddWithValue("@borrowerId", BorrowerID);
                    }
                    else
                    {
                        // Insert new borrower
                        query = "INSERT INTO Borrowers (Name, Email, Phone) VALUES (@name, @email, @phone)";
                        command = new MySqlCommand(query, connection);
                        command.Parameters.AddWithValue("@name", txtName.Text.Trim());
                        command.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                        command.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                    }

                    int rowsAffected = command.ExecuteNonQuery(); // Execute the command

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show(IsEditMode ? "Borrower updated successfully!" : "Borrower added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.DialogResult = DialogResult.OK; // Set dialog result to OK to indicate success to calling form
                        this.Close(); // Close the form
                    }
                    else
                    {
                        lblErrorMessage.Text = IsEditMode ? "Failed to update borrower." : "Failed to add borrower.";
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Database error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Event handler for the Cancel Button (button2) click
        private void button2_Click(object sender, EventArgs e) // Cancel Button
        {
            this.DialogResult = DialogResult.Cancel; // Set dialog result to Cancel
            this.Close(); // Close the form
        }

        // Event handler for the Borrowers_Management form Load event
        private void Borrowers_Management_Load(object sender, EventArgs e)
        {
            // Any specific logic for when the Borrowers_Management form loads, e.g., to load data
            // For now, it's empty as data loading for main display is handled by Main_Window.
        }
    }
}
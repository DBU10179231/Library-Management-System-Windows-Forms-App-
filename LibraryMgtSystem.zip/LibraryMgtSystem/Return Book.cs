﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Linq; // Added for .FirstOrDefault()
using System.Windows.Forms;

namespace LibraryMgtSystem
{
    public partial class Return_Book : Form
    {
        // Connection string for the Return_Book form
        // IMPORTANT: In a production application, store connection strings securely.
        private string connectionString = "Server=localhost;Database=LibrarySystem;Uid=admin;Pwd=admin123;";

        public Return_Book()
        {
            InitializeComponent();
            InitializeCustomComponents(); // Custom initialization for error message label
            this.Load += new System.EventHandler(this.Return_Book_Load);
        }

        // Custom initialization for UI elements
        private void InitializeCustomComponents()
        {
            // Find the error message label (label3) and initialize its state
            Label lblErrorMessage = this.Controls.Find("label3", true).FirstOrDefault() as Label;
            if (lblErrorMessage != null)
            {
                lblErrorMessage.Text = ""; // Clear any default text
                lblErrorMessage.ForeColor = System.Drawing.Color.Red; // Set color for errors
            }
        }

        // Event handler for the Return_Book form Load event
        private void Return_Book_Load(object sender, EventArgs e)
        {
            LoadIssuedBooksData(); // Load unreturned issued books into the DataGridView
        }

        // Method to load currently issued (unreturned) books into dataGridView1
        private void LoadIssuedBooksData()
        {
            DataGridView dgvIssuedBooks = this.Controls.Find("dataGridView1", true).FirstOrDefault() as DataGridView;
            if (dgvIssuedBooks == null)
            {
                MessageBox.Show("Issued Books DataGridView (dataGridView1) not found. Please ensure it exists and is named correctly.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Configure DataGridView properties for display and selection
            dgvIssuedBooks.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvIssuedBooks.ReadOnly = true;
            dgvIssuedBooks.AllowUserToAddRows = false;
            dgvIssuedBooks.AllowUserToDeleteRows = false;
            dgvIssuedBooks.MultiSelect = false;
            dgvIssuedBooks.AutoGenerateColumns = true; // Allow auto-generation of columns from DataTable
            dgvIssuedBooks.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Fill available space

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    // Query to get all currently issued books (ReturnDate is NULL)
                    string query = @"
                        SELECT
                            ib.IssueID,
                            b.BookID,        -- Include BookID here for efficiency in button_Click
                            b.Title AS BookTitle,
                            bo.Name AS BorrowerName,
                            ib.IssueDate,
                            ib.DueDate
                        FROM IssuedBooks ib
                        JOIN Books b ON ib.BookID = b.BookID
                        JOIN Borrowers bo ON ib.BorrowerID = bo.BorrowerID
                        WHERE ib.ReturnDate IS NULL
                        ORDER BY ib.IssueDate DESC";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                        {
                            DataTable issuedBooks = new DataTable();
                            adapter.Fill(issuedBooks); // Fill DataTable with results
                            dgvIssuedBooks.DataSource = issuedBooks; // Set DataGridView's data source

                            // Hide IssueID and BookID columns as they are internal identifiers
                            if (dgvIssuedBooks.Columns.Contains("IssueID"))
                            {
                                dgvIssuedBooks.Columns["IssueID"].Visible = false;
                            }
                            if (dgvIssuedBooks.Columns.Contains("BookID"))
                            {
                                dgvIssuedBooks.Columns["BookID"].Visible = false;
                            }
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Database error loading issued books for return: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error occurred loading issued books for return: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Event handler for the Return Selected Book Button (button1) click
        private void button1_Click(object sender, EventArgs e) // Return Selected Book
        {
            Label lblErrorMessage = this.Controls.Find("label3", true).FirstOrDefault() as Label;
            // Clear previous error message
            if (lblErrorMessage != null) lblErrorMessage.Text = "";

            // Get reference to UI control
            DataGridView dgvIssuedBooks = this.Controls.Find("dataGridView1", true).FirstOrDefault() as DataGridView;

            // Check if UI controls are found
            if (dgvIssuedBooks == null || lblErrorMessage == null)
            {
                MessageBox.Show("One or more UI controls (dataGridView1, label3) were not found. Please ensure they exist and are named correctly.", "UI Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check if a row is selected
            if (dgvIssuedBooks.SelectedRows.Count == 0)
            {
                lblErrorMessage.Text = "Please select an issued book to return.";
                return;
            }

            // Get IssueID and BookID from the selected row
            // (Assumes IssueID and BookID columns are available in the DataGridView's DataSource)
            int issueId = Convert.ToInt32(dgvIssuedBooks.SelectedRows[0].Cells["IssueID"].Value);
            int bookId = Convert.ToInt32(dgvIssuedBooks.SelectedRows[0].Cells["BookID"].Value);

            // Confirm return with the user
            DialogResult confirm = MessageBox.Show("Are you sure you want to return the book '" + dgvIssuedBooks.SelectedRows[0].Cells["BookTitle"].Value.ToString() + "'?", "Confirm Return", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.No)
            {
                return;
            }

            // Use a transaction for atomicity: Increment copies AND update issued record
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlTransaction transaction = null;

            try
            {
                connection.Open();
                transaction = connection.BeginTransaction(); // Start transaction

                // 1. Increment AvailableCopies in Books table
                string updateBookQuery = "UPDATE Books SET AvailableCopies = AvailableCopies + 1 WHERE BookID = @bookId";
                MySqlCommand updateBookCmd = new MySqlCommand(updateBookQuery, connection, transaction);
                updateBookCmd.Parameters.AddWithValue("@bookId", bookId);
                updateBookCmd.ExecuteNonQuery();

                // 2. Update ReturnDate in IssuedBooks table (flag as returned)
                string updateIssuedBookQuery = "UPDATE IssuedBooks SET ReturnDate = @returnDate WHERE IssueID = @issueId";
                MySqlCommand updateIssuedBookCmd = new MySqlCommand(updateIssuedBookQuery, connection, transaction);
                updateIssuedBookCmd.Parameters.AddWithValue("@returnDate", DateTime.Now.Date); // Set return date to today
                updateIssuedBookCmd.Parameters.AddWithValue("@issueId", issueId);
                updateIssuedBookCmd.ExecuteNonQuery();

                transaction.Commit(); // Commit the transaction if all operations succeed
                MessageBox.Show("Book returned successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Refresh the DataGridView to show updated status (removed returned book from list)
                LoadIssuedBooksData();
                this.DialogResult = DialogResult.OK; // Indicate success to calling form
            }
            catch (MySqlException ex)
            {
                transaction?.Rollback(); // Rollback transaction on MySQL error
                MessageBox.Show("Database error during return: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblErrorMessage.Text = "Database error during return.";
            }
            catch (Exception ex)
            {
                transaction?.Rollback(); // Rollback transaction on any other error
                MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblErrorMessage.Text = "An unexpected error occurred.";
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close(); // Ensure connection is closed
                }
            }
        }

        // Event handlers for labels (no specific logic needed)
        private void label1_Click(object sender, EventArgs e) { } // Issued Books Label
        private void label2_Click(object sender, EventArgs e) { } // Placeholder label (if any)
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { } // DataGridView click (no specific logic needed)
    }
}